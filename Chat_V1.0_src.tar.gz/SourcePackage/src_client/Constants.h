#ifndef CONSTANTS_H
#define CONSTANTS_H

    #define BUFFSIZE 1024
    #define WINDOW_WIDTH 800
    #define WINDOW_HEIGHT 500
   
    #define BUTTON_BOX_WIDTH 300
    #define BUTTON_BOX_HEIGHT 30
   
    #define PANE_SIZE 250
 
    #define RESIZE_WINDOW false

#endif
