#ifndef MESSAGELIST_H
#define MESSAGELIST_H

typedef struct Message MESSAGE;
typedef struct MessageEntry MENTRY;
typedef struct MessageList MLIST;


struct MessageList
{
	int count;
	MENTRY* First;
	MENTRY* Last; 
};

struct MessageEntry
{
	MLIST* List;
	MENTRY* Next;
	MENTRY* Prev;
	MESSAGE* Message;
};

struct Message
{
	char* sender;
	char* receiver;
	char* message;
};


MENTRY* CreateMessageEntry(MESSAGE* message);
void DeleteMessageEntry(MENTRY* entry);

MLIST* CreateMessageList();
void DeleteMessageList(MLIST* list);

void DeleteMessage(MESSAGE* message);

void RemoveMessage(MLIST* list, int index);
void RemoveAllMessages(MLIST* list, char* username);
void AppendMessage(MLIST* list, char* sender, char*receiver, char* text);

void PrintMessage(MESSAGE* sender);
void PrintMessageList(MLIST* list);
#endif
