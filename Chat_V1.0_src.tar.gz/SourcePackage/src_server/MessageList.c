#include <stdio.h>
#include <stdlib.h>

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include "MessageList.h"

/*for testing*/


MENTRY *CreateMessageEntry(MESSAGE* message)
{
	MENTRY* NewEntry;
	NewEntry = malloc(sizeof(MENTRY));
	NewEntry -> List = NULL;
	NewEntry -> Next = NULL;
	NewEntry -> Message = message;
	
	return NewEntry;
	
}

void DeleteMessageEntry(MENTRY* entry)
{
	if (entry == NULL)
	{
		return;
	}
	
	entry -> List = NULL;
	entry -> Next = NULL;
	entry -> Prev = NULL;
	entry -> Message = NULL;
	
	if(entry->Message != NULL)
	{
		DeleteMessage(entry->Message);
	}
	
	free(entry);
	entry = NULL;
}

MLIST* CreateMessageList()
{
	MLIST* NewList;
	NewList = malloc(sizeof(MLIST));
	NewList -> count = 0;
	NewList -> First = NULL;
	NewList -> Last = NULL;
	
	
	return NewList;
	
}

void DeleteMessageList(MLIST* list)
{
	if(list == NULL)
	{
		return;
	}
	
	MENTRY* curr;
	MENTRY* next;
	
	curr = list -> First;
	
	list -> count = 0;
	list -> First = NULL;
	
	while(curr != NULL)
	{
		next = curr-> Next;
		DeleteMessageEntry(curr);
		curr = next;
	}
	
	free(list);
	list = NULL;
}

void DeleteMessage(MESSAGE* message)
{
	if(message != NULL)
	{
		free(message->sender);
		free(message->receiver);
		free(message->message);
		free(message);
		message = NULL;
	}
} 

void RemoveMessage(MLIST* list, int index)
{
	int currentIndex = 0;
	MENTRY* currentEntry = list -> First;
	MENTRY* nextEntry = NULL;
	MENTRY* prevEntry = NULL;
	
	while(currentEntry != NULL)
	{
		nextEntry = currentEntry -> Next;
		prevEntry = currentEntry -> Prev;
		
		if(index == currentIndex)
		{
			if(prevEntry != NULL)
			{	
			    prevEntry -> Next = nextEntry;
			}

			if(nextEntry != NULL)
			{
			    nextEntry -> Prev = prevEntry;
			}
			DeleteMessageEntry(currentEntry);
		}
		currentEntry = nextEntry;
		currentIndex++;
	}
}
void RemoveAllMessages(MLIST* list, char* username)
{
	MENTRY* currentEntry = list -> First;
	MENTRY* nextEntry = NULL;
	MENTRY* prevEntry = NULL;
	
	while(currentEntry != NULL)
	{
		nextEntry = currentEntry -> Next;
		prevEntry = currentEntry -> Prev;
			
			if (strcmp(username, currentEntry->Message->receiver) == 0)
			{
				if(prevEntry != NULL)
				{	
					prevEntry -> Next = nextEntry;
				}
				else
				{
				        list -> First = nextEntry;
				}	

				if(nextEntry != NULL)
				{
					nextEntry -> Prev = prevEntry;
				}
				else
 				{
					list -> Last = prevEntry;
				}

				(list->count)--;
				DeleteMessageEntry(currentEntry);
			}
			currentEntry = nextEntry;
	}
}

void AppendMessage(MLIST* list, char* sender, char* receiver, char* text)
{
        MESSAGE* message = malloc(sizeof(MESSAGE));
	message->sender = malloc(sizeof(char*));
	message->receiver = malloc(sizeof(char*));
	message->message = malloc(sizeof(char*));
	strcpy(message->sender, sender);
	strcpy(message->receiver, receiver);
	strcpy(message->message, text);

	printf("Value of sender is %s\n", message->sender);
	printf("Value of receiver is %s\n", message->receiver);
	printf("Value of message is %s\n", message->message);
	printf("Appending message now...\n");
 
	MENTRY* curr = CreateMessageEntry(message);

	if(list -> Last != NULL)
	{
		curr -> List = list;
		curr -> Next = NULL;
		curr -> Prev = list -> Last;
		list->Last->Next = curr;
		list->Last = curr;
	}
	else
	{
		curr -> List = list;
		curr -> Next = NULL;
		curr -> Prev = NULL;
		list -> First = curr;
		list -> Last = curr;
	}
	list -> count++;
}

void PrintMessage(MESSAGE* Message)
{
	if(Message == NULL)
	{
		printf("message is NULL");
		return;
	}
	else
	{
		printf("%s\n", Message -> message);
	}
}


void PrintMessageList(MLIST* list)
{
	printf("The number of entriess in list = %d. \n", list -> count);
	MENTRY *curr = list -> First;
	if(curr != NULL)
	{
            printf("The first message of the list is %s\n", list->First->Message->message);
            printf("The current message = %s\n", curr->Message->message);
	    printf("Printing list now...\n");
	}
	while (curr != NULL)
	{
	//	currentIndex++;
		PrintMessage(curr->Message);
		curr = curr -> Next;
	}
}




